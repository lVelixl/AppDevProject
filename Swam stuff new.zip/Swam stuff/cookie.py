import shelve


def cookie():
    db = {}
    cookieDb = shelve.open("cookie.db", "c")
    try:
        db = cookieDb["cookie"]
    except:
        print("ABC")

    db["cookie"] = "creatitools@creatitools.org"
    cookieDb.close()
    return db

    db=shelve.open('cookie,db','r')
    User=db['ActiveAccount']
    db.close()
    render_template('home.html',User=User)
def SIGNOUT(cookieDict):
    cookieDb = shelve.open("cookie.db", "c")
    cookieDict["cookie"] = ","
    cookieDb["cookie"] = cookieDict
    cookieDb.close()

