from wtforms import Form, StringField, validators, ValidationError


class importForm(Form):
    username = StringField("", [validators.DataRequired(), validators.Length(max=20)])
    password = StringField("", [validators.DataRequired(), validators.Length(max=20)])
    confirmpassword=StringField("", [validators.DataRequired(), validators.Length(max=20)])
    email=StringField("", [validators.email(message="Invalid Email address! Please try again!"), validators.Length(max=40)])

class signinForm(Form):
    username = StringField("email", [validators.DataRequired(), validators.Length(max=20)])
    username=StringField("", [validators.email(message="Invalid Email address! Please try again!"), validators.Length(max=40)])
    password = StringField("password", [validators.DataRequired(), validators.Length(max=20)])

