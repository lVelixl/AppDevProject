from flask import Flask, render_template, request, redirect, url_for
import shelve, cookie, Forms, base64, Account
from Forms import importForm as iF
from Forms import signinForm as sF


app = Flask(__name__, static_folder="static")
cookieDict = cookie.cookie()


@app.route('/')
def home():
    return render_template("home.html", cookieDict=cookieDict)


@app.route("/signup", methods =['GET','POST'])
def signup():
    #if request.form == 'POST':
    SignUpForm = iF(request.form)
    if request.method == 'POST' and SignUpForm.validate():
        if SignUpForm.confirmpassword.data == SignUpForm.password.data:
            AccountDict = {}
            db = shelve.open('storage.db', 'c')
            acc = Account.Account(SignUpForm.username.data, SignUpForm.password.data, SignUpForm.confirmpassword.data, SignUpForm.email.data)
            AccountDict[acc.get_name()] = acc
            db['AccountDatabase'] = AccountDict
            db.close()
            return redirect(url_for('home'))
        else:
            print('Password not the same!')
            return redirect(url_for('signup'))
    if request.method == 'POST' and SignUpForm.validate():
        if SignUpForm.email=="@gmail.com":
            AccountDict = {}
            db = shelve.open('storage.db', 'c')
            acc = Account.Account(SignUpForm.username.data, SignUpForm.password.data, SignUpForm.confirmpassword.data, SignUpForm.email.data)
            AccountDict[acc.get_name()] = acc
            db['AccountDatabase'] = AccountDict
            db.close()
            try:
                signupcheck=db.get_username(signup)
            except:
                print('User not found!')
            return redirect(url_for('home'))
        else:
            print('Invalid email!')
            return redirect(url_for('signup'))
    return render_template("signup.html", cookieDict=cookieDict, form=SignUpForm)

@app.route("/signin",methods=['GET','POST'])

def signin():
    SignInForm = sF(request.form)
    userDict={}
    db=shelve.open('userdatabase.db','r')
    userDict=db['AccountDatabase']
    db.close()
    emailinput = SignInForm.username.data
    passwordinput = SignInForm.password.data
    try:
        object = userDict.get(emailinput)
    except:
        print('Email Not found')
        return redirect(url_for('signin'))

    passwordverify = object.get_password()
    if passwordverify == passwordinput:
        return redirect(url_for('home'))
    else:
        return redirect(url_for('signin'))

    if request.method == 'POST' and SignInForm.validate():

        if SignInForm.password.data == SignInForm.password.data:
            AccountDict = {}
            db = shelve.open('storage.db', 'c')
            acc = Account.Account(SignInForm.username.data, SignInForm.password.data)
            AccountDict[acc.get_email()] = acc
            db['AccountDatabase'] = AccountDict
            db.close()
            return redirect(url_for('home'))
        else:
            return redirect(url_for('signin'))
    else:
        return render_template("signin.html", cookieDict=cookieDict, form=SignInForm)

@app.route('/retrieveUser')
def retrieveuser():
    retrieveuser=()
    db = shelve.open('storage.db','x')
    userDict=db['Staff']
    db.close()
    userList=[]
    for key in userDict:
        user=userDict.get(key)
        userList.append(user)
    return render_template('retrieveUser.html',userList=userList,count=len(userList))


if __name__ == '__main__':
    app.run()

@app.route('/profileuser')

def profileuser():
    return render_template("ProfileSettings.html", cookieDict=cookieDict)
