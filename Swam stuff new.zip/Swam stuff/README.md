# AppDevProject
This is all for Assignment :3
Things to Do:

-Link all Pages Up, static or likewise.
-Start with CRUD- Probably R first.
-Ensure that information are parsed and passed correctly
